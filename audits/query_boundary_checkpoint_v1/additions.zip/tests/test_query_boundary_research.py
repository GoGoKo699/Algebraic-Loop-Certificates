"""Additive reduction/comparator audit; no primary certificate API expansion."""
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]


class QueryBoundaryResearch(unittest.TestCase):
    def test_preprocessing_and_projection_boundaries(self):
        prefix = [sys.executable] + (['-O'] if not __debug__ else [])
        subprocess.run(prefix + [str(ROOT / 'research/query_boundary_audit_v1/verify.py')],
                       cwd=ROOT, check=True, timeout=240)


if __name__ == '__main__':
    unittest.main()
