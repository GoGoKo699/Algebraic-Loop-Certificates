"""Exact tests for the claimed reductions and equally compact classical comparison."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from collections import Counter
from copy import deepcopy
from itertools import combinations, combinations_with_replacement, permutations, product
import argparse, hashlib, json, random
from alc.schema import Invalid
from alc.checker import prime_proofs
from research.compiled_orbits_v1.producer import produce
from research.compiled_orbits_v1.checker import compile_orbit
from research.query_boundary_audit_v1.boundaries import (
    diagonal_source, checked_log_from_alignment, CharacterPredicate,
    FixedPermutationSource, crt_bits, formula_value)


def require(ok, message):
    if not ok:
        raise AssertionError(message)


def reindex(cert, ordering):
    result = deepcopy(cert)
    result['components'] = [deepcopy(cert['components'][i]) for i in ordering]
    inverse = {old: new for new, old in enumerate(ordering)}
    for e in result['comparisons']:
        a, b = inverse[e['i']], inverse[e['j']]
        if a > b:
            from math import gcd
            D = gcd(cert['components'][e['i']]['order'], cert['components'][e['j']]['order'])
            a, b = b, a
            e['left_root'], e['right_root'] = e['right_root'], e['left_root']
            e['alignment'] = pow(e['alignment'], -1, D)
        e['i'], e['j'] = a, b
    return result


def prime_order_checks(native=False):
    counts = Counter()
    digest = hashlib.sha256()
    native_sources = []
    for p in (7, 11, 23, 47):
        q, g = (p-1)//2, 4
        require(len({pow(g, j, p) for j in range(q)}) == q, 'Chosen generator order incorrect.')
        for s in range(q):
            h = pow(g, s, p)
            source = diagonal_source(p, g, h)
            out = produce(source)
            require(out['status'] == 'candidate', 'Unexpected small synthesis timeout.')
            cert = out['certificate']
            ci = compile_orbit(source, cert)
            ps = prime_proofs(cert['prime_proofs'], ci.limits, {'modular_power_checks': 0})
            require(p in ps and q in ps, 'Missing prime proofs in comparator inputs.')
            extracted = checked_log_from_alignment(source, cert, q)
            require(extracted == s, 'Alignment extraction does not recover original exponent.')
            conventional = CharacterPredicate(p, q, g, h, extracted)
            truth = {(pow(g, t, p), pow(h, t, p)) for t in range(q)}
            for u, v in product(range(p), repeat=2):
                old_answer = ci.query([u, v])['status'] == 'reachable'
                new_answer = conventional.query((u, v))
                require(old_answer == new_answer == ((u, v) in truth), 'Comparator or DDH reduction failed.')
                digest.update(json.dumps([p, s, u, v, old_answer]).encode())
                counts['full_state_comparisons'] += 1
                counts['reachable' if old_answer else 'unreachable'] += 1
            for ordering in permutations(range(len(cert['components']))):
                changed = reindex(cert, ordering)
                require(checked_log_from_alignment(source, changed, q) == s,
                        'Extraction depends on ordering or alignment orientation.')
                counts['reindexed_certificate_extractions'] += 1
            if h not in (1, g):
                bad = deepcopy(cert)
                bad['comparisons'] = []
                try:
                    checked_log_from_alignment(source, bad, q)
                except Invalid:
                    counts['alignment_omissions_rejected'] += 1
                else:
                    raise AssertionError('Missing source logarithm relation was accepted.')
            wrong_s = (s + 1) % q
            try:
                CharacterPredicate(p, q, g, h, wrong_s)
            except Invalid:
                counts['false_standard_relations_rejected'] += 1
            else:
                raise AssertionError('False source relation accepted by the conventional checker.')
            if native:
                import sympy
                native_q = int(sympy.n_order(g, p))
                native_s = int(sympy.discrete_log(p, h, g)) % native_q
                # Both receive the same canonical diagonal source; no test exponent is passed.
                require((native_q, native_s) == (q, s), 'Native arithmetic disagrees with extraction.')
                native_sources.append({'p': p, 'g': g, 'h': h, 'order': native_q, 'alignment': native_s})
            counts['sources'] += 1
    return {'counts': dict(sorted(counts.items())), 'outcomes_sha256': digest.hexdigest()}, native_sources


def guard_checks():
    counts = Counter()
    digest = hashlib.sha256()
    rng = random.Random(2026092705)
    source_stats = []
    for n in range(1, 5):
        source = FixedPermutationSource(n)
        # Formulas do not exist yet: construct and verify source first.
        current = source.initial
        states = []
        for t in range(source.period):
            require(current == source.at(t), 'Source powering differs from direct permutation.')
            require(source.recognize(current), 'Polynomial point recognizer rejects an orbit state.')
            states.append(current)
            current = source.step(current)
        require(current == source.initial and len(set(states)) == source.period, 'Point period not exact.')
        truth = set(states)
        for _ in range(100):
            y = list(states[rng.randrange(source.period)])
            j = rng.randrange(source.dimension)
            y[j] ^= 1
            require(source.recognize(y) == (tuple(y) in truth), 'Mutated full-state recognition differs.')
            counts['mutated_point_queries'] += 1
        clauses = [b.label for b in source.blocks if b.kind == 'clause']
        formulas = [(), ((1,), (-1,)), ((),), ((1, -1),)]
        if n <= 2:
            for length in range(1, 4):
                formulas.extend(combinations_with_replacement(clauses, length))
        elif n == 3:
            formulas.extend((c,) for c in clauses)
            formulas.extend(combinations(clauses, 2))
            # Eight clauses collectively forbid every assignment, each separately possible.
            formulas.append(tuple(tuple(sign*(i+1) for i, sign in enumerate(signs))
                                  for signs in product((-1, 1), repeat=3)))
        for _ in range(120):
            formulas.append(tuple(rng.choice(clauses) for _ in range(rng.randrange(1, 13))))
        before = hashlib.sha256(bytes(source.initial)).hexdigest()
        for formula in formulas:
            coords = source.projection(formula)
            actual_times = [t for t, state in enumerate(states) if all(state[i] == 1 for i in coords)]
            assignments = [bits for bits in product((0, 1), repeat=n) if formula_value(formula, bits)]
            predicted_times = sorted(crt_bits(bits, source.primes) for bits in assignments)
            require(actual_times == predicted_times, '3SAT-to-projection equivalence/count identity failed.')
            digest.update(json.dumps([n, formula, coords, actual_times]).encode())
            counts['formulas'] += 1
            counts['satisfiable' if actual_times else 'unsatisfiable'] += 1
            counts['projected_time_checks'] += source.period
            counts['assignment_checks'] += 1 << n
        require(before == hashlib.sha256(bytes(source.initial)).hexdigest(), 'Formula changed the fixed source.')
        counts['fixed_sources'] += 1
        counts['full_point_queries'] += source.period
        source_stats.append({'variables': n, 'primes': list(source.primes),
                             'dimension': source.dimension, 'blocks': len(source.blocks),
                             'period': source.period, 'formula_cases': len(formulas),
                             'initial_sha256': before})
    # Composition with a generic exact orbit recognizer for a small fixed source.
    # n=1 is within the primary max-dimension policy; the larger source is not
    # silently claimed to have passed the polynomial-factor compiler.
    s = FixedPermutationSource(1)
    A = [[int(s.permutation[i] == j) for j in range(s.dimension)] for i in range(s.dimension)]
    doc = {'schema': 'alc.orbit-source.v1', 'field': {'kind': 'prime', 'modulus': 2},
           'matrix': A, 'offset': [0] * s.dimension, 'initial': list(s.initial)}
    candidate = produce(doc)
    require(candidate['status'] == 'candidate', 'Small integration compile failed.')
    ci = compile_orbit(doc, candidate['certificate'])
    for y in product((0, 1), repeat=s.dimension):
        require((ci.query(list(y))['status'] == 'reachable') == s.recognize(y),
                'Fixed-family recognizer differs from general checked compiler.')
        counts['generic_compiler_crosschecks'] += 1
    return {'counts': dict(sorted(counts.items())), 'sources': source_stats,
            'outcomes_sha256': digest.hexdigest()}


def run(native=False):
    prime_order, native_results = prime_order_checks(native)
    guards = guard_checks()
    exact = {'schema': 1, 'prime_order_compilation': prime_order, 'projected_queries': guards,
             'scope': 'Exact finite checks of elementary reductions and a conventional compact comparator. '
                      'Hardness conclusions require the written reductions; no novelty, asymptotic lower bound '
                      'for all compilers, native performance advantage, or formal code verification is claimed.'}
    optional = None
    if native:
        import sympy
        optional = {'sympy_version': sympy.__version__, 'sources': native_results,
                    'scope': 'Native order/logarithm computation on the same 42 small diagonal sources; '
                             'not a performance study or a native invariant-system implementation.'}
    return exact, optional


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--native-output', type=Path)
    args = p.parse_args()
    if args.output.exists() or (args.native_output and args.native_output.exists()):
        raise SystemExit('Refusing to overwrite evidence.')
    result, native = run(args.native_output is not None)
    for path, value in ((args.output, result), (args.native_output, native)):
        if path is not None:
            with path.open('x', encoding='utf-8') as f:
                json.dump(value, f, indent=2, sort_keys=True)
                f.write('\n')
    print(json.dumps(result, indent=2, sort_keys=True))
