# What source compilation buys, and which queries it cannot make cheap

Research audit, 27 September 2026. Baseline commit:
`5270aa58e92458fbcb111b7bdeb794777e030b41`.
Manuscript drafting is on hold. This note contains mathematical reductions and
scope corrections, not a manuscript or a claim that every result below is new.
No existing certificate interface or historical evidence is changed.

## 1. Why this audit is needed

The compiled-orbit result provides, for each explicit invertible affine source
S=(p,A,c,a), a polynomial-size checked description of its initial orbit. Its
online predicate decides full-state membership in polynomial time, without a
new finite-field target discrete logarithm. The certificate may be difficult
to construct. It does not return the first hitting time, and it does not solve
intersection of the orbit with an arbitrary partially specified target.

This audit proves three precise qualifications:

1. Even a two-dimensional diagonal source contains the standard decision
   Diffie-Hellman relation. Moreover, on a prime-order family, producing ANY
   accepted certificate in our current format reveals a source logarithm.
2. Once that relation is known, an ordinary compact character predicate gives
   the same diagonal membership answers. No quantum or newly discovered
   invariant principle is needed for this special case.
3. For a uniformly constructible family of Boolean permutation sources, one
   source per number of variables, full-state recognition is easy, but choosing
   a coordinate projection whose target is all ones yields NP-complete
   reachability, coNP-complete absence, and #P-complete counting over one period.

These statements do not invalidate the compiled-orbit theorem. They locate its
preprocessing cost, its closest simple comparator, and its query boundary.
Direct predecessors and reading limits are recorded in SOURCES.md. In
particular, projected reachability hardness for Boolean dynamical systems was
already published; it must not be presented as this project's first discovery.

## 2. A two-coordinate source is a Diffie-Hellman consistency problem

Let p and q be primes with q>=3 and q dividing p-1. Let g in F_p have exact
multiplicative order q and let h=g^s, with 0<=s<q. Define

    F(u,v)=(g*u,h*v),      a=(1,1).

The initial orbit consists exactly of

    (g^t,h^t)=(g^t,g^(s*t)),       0<=t<q.

For u=g^t and an arbitrary v in the order-q subgroup, deciding whether (u,v)
is on this orbit is precisely the decision Diffie-Hellman consistency test for
(g,h,u,v). A uniform polynomial-time source compiler followed by a polynomial-
time query algorithm would therefore decide these DDH instances in polynomial
time. Both the source and the queried state have O(log p) bits, apart from
constant-sized matrix overhead.

This is a direct algebraic identity, not an unconditional complexity lower
bound. We do not assert that DDH and search discrete logarithms are equivalent,
or that DDH is difficult in every group. We use prime-order subgroups, not an
unqualified hardness assumption on the entire multiplicative group F_p^*.
Boneh's primary survey [S1] supplies the established decision/search terminology.

Giving a recognizer an already known s makes these queries elementary. The
question is what is required to obtain that source-dependent information.

## 3. Every accepted current-format certificate reveals a source logarithm

**Proposition (format-specific extraction).** Under the promises in Section 2,
given ANY valid `alc.compiled-orbit.v1` certificate for the specified source,
log_g(h) can be recovered in time polynomial in the input and certificate length.
The conclusion is independent of the reference producer, component ordering,
and orientation of the comparison edge.

**Proof.** If h=1 or h=g, the answer is respectively 0 or 1. Otherwise 1,g,h
are distinct. The affine lift is diag(g,h,1), and its initial vector is (1,1,1).
Its initial-vector minimal polynomial is

    mu=(X-g)(X-h)(X-1).

The three eigenvalues are distinct and each appears with a nonzero initial
coordinate, so none of the three factors can be omitted. The checked factor
list therefore contains exactly these three linear factors. The first two
associated element orders are q; the last is 1.

The q-support of the compatibility graph contains exactly the g and h
components. The graph-coverage obligation therefore forces an edge between
them. A comparison algebra for two degree-one factors has positive degree at
most one; independently, its verified factor-root identities force the images
to be the constants g and h. The common-order comparison has D=q and hence
certifies one of the following identities:

    g=h^c,  if the left component is g;
    h=g^c,  if the left component is h.

The format checks 1<=c<q and gcd(c,q)=1. In the first orientation s=c^(-1) mod q;
in the second s=c. This determines the unique discrete logarithm. Final
exponentiation g^s=h can be checked directly. QED.

Consequently, a procedure that produces an accepted current-format certificate
in polynomial time for every promised source would solve these search
logarithms in polynomial time. This is stronger than observing that our
particular BSGS implementation happens to compute one. It holds for every
producer whose output passes this certificate checker.

**Limits of the proposition.** This is not a proof that every conceivable
polynomial-size orbit recognizer contains an extractable logarithm. Another
representation could have different information content. It also does not
prove that the full certificate-construction problem is polynomial-time
EQUIVALENT to discrete logarithms: integer factorization and primality-proof
production are separate obligations outside this reduction. The extraction is
unconditional algebra; any assertion of superpolynomial construction time
requires an appropriate computational assumption.

The executable extractor validates the certificate first. It is a diagnostic
for this source family, not a new trusted proof format. Small tests permute the
component indices and reverse comparison orientation to prevent an accidental
reliance on the reference producer's ordering.

## 4. An equally compact conventional comparator

Suppose the same source preprocessing supplies s, with verified g^s=h, and the
prime-order promise is justified by checked primes p,q, g!=1 and g^q=1. Then

    P(u,v) = [u^q=1 in F_p AND v=u^s in F_p]

is an exact orbit predicate. The first equality says u belongs to the unique
subgroup of order q generated by g. If u=g^t, the second equality says exactly
v=g^(s*t)=h^t. Conversely every orbit point satisfies both equations.

This is standard cyclic-group/character reasoning. A compact circuit for the
powers costs polynomial time in log p; a fair competitor is not required to
expand the powers into monomials or compute t on every query. Our general
compiler must be compared against this source-aware formulation on the
corresponding special case, not against repeated discrete-logarithm queries.

`CharacterPredicate` is deliberately reference code, not a new public
certificate API. Its dataclass assumes already checked primality/order
preconditions. The audit establishes those preconditions using the existing
prime-proof machinery before comparing predicates. It is not an unforgeable
object or a standalone general primality verifier.

The optional native comparison asks SymPy for n_order(g,p) and
 discrete_log(p,h,g), supplying exactly the same source and no generating
exponent, order hint or factorization hint. The native results agree on the
42 recorded sources. No timing or general native-invariant superiority result
is inferred. This is a concrete mathematical comparator and a correctness
comparison, not a benchmark selected to manufacture a speedup.

## 5. Projected targets introduce an existential completion problem

Full-state membership asks whether a supplied y occurs. A coordinate-projection
query supplies a set J of observed coordinates and a pattern b_J and asks

    Does there exist t>=0 such that (F^t(a))_J=b_J?

Equivalently, does some completion of the unobserved coordinates belong to the
orbit? An efficiently evaluated complete-state predicate does not eliminate
that existential quantifier.

For the restricted family constructed next, even the special pattern b_J=1 on
every selected coordinate suffices for NP-completeness. The dynamics have no
nonlinear update, branching, nondeterminism or unknown initial state. They are
just an explicit permutation of Boolean coordinates, hence an invertible linear
map over F_2.

## 6. One formula-independent permutation source per variable count

For n>=1 let p_1,...,p_n be the first n primes. Put R=product_i p_i. Construct
one fixed source S_n, depending only on n, as disjoint rotating bit blocks.
Every block update is a right rotation by one position. The distinguished
observation coordinate in a block is its position zero.

A block of length L with desired observation function b(t), periodic modulo L,
has initial word w_j=b(-j mod L). After t rotations its position-zero value is
w_(-t mod L)=b(t). All initial words are constructed explicitly; there is no
oracle hiding their values.

### Domain blocks

For each variable i, add a block of length p_i whose observation at time t is

    D_i(t)=1 iff t mod p_i belongs to {0,1}.

Requiring all these coordinates to be one restricts the time residues to a
Boolean assignment x_i=t mod p_i.

### Clause blocks

For EVERY non-tautological signed clause C on between one and three distinct
variables, add a block of length product_(i in vars(C)) p_i. At time t its
observation is one when at least one of these conditions holds:

    t mod p_i=1 for a positive occurrence of x_i;
    t mod p_i=0 for a negative occurrence of x_i.

On times that pass the domain blocks, this is exactly the Boolean truth value
of C. Its behavior outside those domain constraints is irrelevant.

The source includes all such clauses in advance; a later formula changes only
which existing observation coordinates are requested. Duplicate clauses can
be deduplicated. Tautologies request no clause coordinate. An empty clause can
be represented by jointly requesting the positive and negative unary clause
coordinates of variable one, which can never be one simultaneously.

### Size and uniform construction

There are sum_(j=1)^3 2^j binom(n,j)=O(n^3) clause blocks. The standard prime
bound p_n=O(n log(n+1)) gives

    D_n = sum_i p_i + sum_(1<=|T|<=3) 2^|T| product_(i in T) p_i
        = O(n^6 log^3(n+1)).

The source can be constructed deterministically in polynomial time by ordinary
prime sieving/trial primality and by writing the indicated polynomially many
bits. The sparse permutation representation has O(D_n log D_n) bits; even an
explicit dense F_2 matrix has polynomial size O(D_n^2). An exponentially large
truth table is not being supplied implicitly. log R=O(n log(n+1)). The
implementation has additional explicit size limits; those are not part of the
asymptotic theorem.

## 7. Full-state recognition for this family is uniformly easy

Every block length divides R, so R is a period. The positive unary clause for
variable i has observation one exactly when t mod p_i=1. Its initial word is a
single one at position p_i-1. It has least period p_i. Therefore the least
period of the entire initial state is exactly R.

Given a complete candidate state y, inspect these unary anchor blocks. Each
must contain exactly one bit equal to one. If that bit is in position j_i,
the only possible time residue is t=j_i+1 mod p_i. Coprime CRT determines a
unique t in [0,R). Check all remaining blocks against their initial words
rotated by t. Accept if and only if every bit matches.

This requires O(D_n) bit comparisons and polynomial-time CRT arithmetic. Both
the source and this recognizer are uniformly available without hard algebraic
preprocessing. Hence the projected-target result below is not merely a
consequence of expensive source compilation left uncharged.

Permutation-source point recognition is established prior work [S2]. The
anchor-based version here is a direct special-case comparator with an explicit
proof. It is not a new general algorithm for permutation actions.

## 8. Projection reachability and counting reduce exactly to satisfiability

Let phi be any 3-CNF formula on n variables. Use the fixed source S_n. Request
all domain observation coordinates and the observation for each clause of phi,
with target value one at each requested coordinate. Denote this selection by
J_phi.

By the Chinese remainder theorem, every assignment x in {0,1}^n corresponds to
exactly one time t in [0,R) with t mod p_i=x_i. That time passes the selected
clause coordinates exactly when x satisfies phi. Thus

    {satisfying assignments of phi}
          <--> {t in [0,R): every selected coordinate is one}
          <--> {distinct orbit states matching the partial target}.

Both arrows are bijections. This is a parsimonious reduction. The dynamics,
initial state, and full-point recognizer are independent of phi; the formula
is encoded only by the projection query.

**Decision.** Existence of a matching projected target is NP-hard by 3-SAT.
It is in NP: guess the binary t in [0,R) and check the required positions by
block rotations. Hence it is NP-complete, even for this uniformly fixed-by-n
family and all-one target patterns. Its complement is coNP-complete.

**Counting.** Counting matching distinct orbit states (equivalently the times
in one least period) is #P-hard by the bijection from #3SAT. It is in #P by
guessing the fixed-length binary encoding of t, rejecting t>=R, and checking
the projection. Each time/state is represented once, so this gives #P-
completeness under parsimonious reductions. The claim concerns one period or
distinct states, NOT the infinitely many repetitions of a matched time.

Projected reachability hardness for Boolean permutation dynamics has close
direct prior art [S2]. We independently give this source-fixed, counting-
preserving construction to establish the exact contract needed by the project.
Priority for that strengthening and its certificate consequences is not claimed
without a further targeted comparison.

## 9. Consequences for preprocessing and for negative certificates

### 9.1 Uniformly efficient compilation cannot remove this query obstruction

If a uniform polynomial-time algorithm constructs a representation of S_n and
a uniform polynomial-time query procedure decides all projected targets on
that representation, then the reduction decides 3-SAT in polynomial time.
Such an algorithm would imply P=NP. This remains true if it is called a guard
solver, an orbit-region intersection method, or a compiler with a query engine.

### 9.2 Arbitrary source-only preprocessing has a different consequence

Suppose the preprocessing is allowed to be unbounded, but its result has size
polynomial in the source size and a fixed polynomial-time online algorithm
handles all projections. Because S_n depends only on n, its compiled result
can serve as polynomial-length advice for all n-variable formulas. Padding
formulas with unused variables gives advice indexed by input length. Therefore
such arbitrary source-only compilation would imply NP is contained in P/poly.
This is not the same as P=NP. It matches the usual need to distinguish uniform
construction from existence of succinct advice in compilation arguments [S3].

### 9.3 Complete short negative proofs would imply NP=coNP

Suppose a uniformly polynomial-time deterministic verifier accepts sound,
polynomial-size certificates for EVERY projected-unreachable instance of this
family. Given an unsatisfiable 3-CNF phi, use the same reduction, guess its
certificate, and verify it. This places UNSAT in NP, hence NP=coNP.

The conclusion is unchanged if the certificate additionally supplies a
polynomial-size source-compilation proof that the verifier checks soundly.
The two polynomial-size witnesses can be concatenated. The crucial assumptions
are uniform checking, polynomial witness length, completeness for all negative
instances in the family, and soundness for satisfiable queries.

This does not prohibit short certificates for particular guards, incomplete
sound invariant methods, interactive/randomized proof systems under different
contracts, or expensive verification. It does not prove NP differs from coNP.
It shows why extending our existing complete point-negative contract to every
coordinate projection would be a qualitatively stronger theorem.

## 10. A small tractable extension, without a universality claim

For any already compiled F_p orbit predicate, if exactly h state coordinates
are unspecified, at most p^h full completions need to be checked. This gives
an exact O(p^h Q) decision/count algorithm, where Q is the full-point query
cost, and checking every rejected completion supplies a potentially large
negative proof. Distinct completions are distinct states, so no duplicate
state counting occurs. This elementary bound is useful only where h log p is
small; it is not polynomial uniformly in h. It is not a new parameterized
algorithmic contribution, and no such guard extension is installed here.

## 11. Evidence, limitations and resulting research decision

The executable audit verifies 57,378 full-state comparisons on 42 diagonal
sources, 220 reordered/orientation-changed certificate extractions, and 42
optional native SymPy source reconstructions. The standard compact character
predicate and the compiled recognizer agree with independent orbit lists in
all those finite cases. The test inputs are intentionally small algebraic
controls, not evidence for or against asymptotic cryptographic assumptions.

Four fixed permutation sources with n=1,2,3,4 have 6,39,394,2431 coordinates
and periods 2,6,30,210. Across 1,021 formula queries, projected matches agree
exactly with the satisfying assignments under the CRT bijection. Tests inspect
42,314 time/projection cases and 7,210 assignment cases, including empty,
contradictory and tautological formulas. The generic compiled-orbit software
is cross-checked on all 64 states of the n=1 source. The larger examples use
the independently written permutation recognizer; their dimensions exceed the
primary compiler's fixed default policy. No larger generic compilation is
implied. Explicit test enumeration is separate from the proof's polynomial
source construction and point recognizer.

This audit narrows rather than inflates the contribution. Source-only point
compilation remains valid, but its no-target-log feature is not itself a new
algebraic advantage, and its query class must not be described as general
program safety. The unresolved positive contribution must lie in a precisely
compared representation, proof-system, verifier-cost or restricted consumer
result. No new certificate format, production API, journal claim, release or
manuscript is introduced by these diagnostics.
