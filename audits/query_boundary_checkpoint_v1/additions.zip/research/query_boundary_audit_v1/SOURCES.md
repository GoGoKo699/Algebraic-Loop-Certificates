# Background, direct predecessors, and what this comparison establishes

Inspected 27 September 2026. These are research records, not manuscript prose.
The proofs in THEORY.md distinguish direct algebraic reductions, conditional
complexity consequences, executable tests, and unresolved priority questions.
No absence from search results is treated as novelty evidence.

## S1. Decision versus search Diffie-Hellman

Dan Boneh, *The Decision Diffie-Hellman Problem*, ANTS III, LNCS 1423,
48-63 (1998).
https://crypto.stanford.edu/~dabo/abstracts/DDH.html
https://crypto.stanford.edu/~dabo/papers/DDH.pdf

Primary author record and parsed full paper were inspected, especially the
problem definitions and group qualifications in the opening sections. A PDF
screenshot request failed; no chart or visual measurement is used. The source
supports the established meaning of the relation (g,g^s,g^t,g^(st)) and the
need to distinguish decision assumptions, computational Diffie-Hellman and
search logarithms. It is not a claim about the fastest currently known
implementation or about hardness in every finite field.

The two-coordinate orbit identity is derived directly in THEORY Section 2.
Section 3 is a separate result ABOUT OUR CURRENT FORMAT: every accepted
certificate on the nondegenerate prime-order diagonal family reveals s.
We do not attribute that format-specific extraction to Boneh, and do not
infer that all possible compact membership representations reveal s.

## S2. A direct predecessor for projected reachability

Mitsunori Ogihara and Kei Uchizawa, *Synchronous Boolean Finite Dynamical Systems
on Directed Graphs over XOR Functions*, MFCS 2020, LIPIcs 170, 76:1-76:13.
https://doi.org/10.4230/LIPIcs.MFCS.2020.76
https://drops.dagstuhl.de/storage/00lipics/lipics-vol170-mfcs2020/LIPIcs.MFCS.2020.76/LIPIcs.MFCS.2020.76.pdf

The primary parsed paper was read at the definitions of full and projected
reachability, the permutation reachability proof (Theorem 11), and the
projected-reachability statement (Theorem 14). The introduction explicitly
describes hardness even for permutation updates. Theorem 14's proof is omitted
in this proceedings text. Screenshot attempts on the relevant later pages
failed; no figure-dependent result is reported.

This is close prior art, not a generic motivation citation. We must not claim
first discovery that omitting coordinates can change reachability from easy to
NP-complete, or that permutations suffice for such hardness. The explicit
source-fixed and parsimonious construction in THEORY Sections 6-8 supplies the
particular offline/online and certificate consequences needed here. We have
not established priority for those refinements over a full extended account or
related periodic-constraint literature.

The paper also discusses broader XOR results attributed to an earlier article.
This audit relies only on the permutation and projected-query statements just
identified; it does not transfer an uninspected broad complexity claim to our
variable-prime affine domain. The direct proof here is self-contained once
standard 3-SAT and CRT facts are supplied.

## S3. Compilation is measured by queries as well as representation size

Adnan Darwiche and Pierre Marquis, *A Knowledge Compilation Map*, Journal of
Artificial Intelligence Research 17, 229-264 (2002).
https://doi.org/10.1613/jair.989
https://arxiv.org/abs/1106.1819
https://arxiv.org/pdf/1106.1819

Primary parsed paper inspected at the opening motivation, query-language
requirements, and succinctness discussion. Printed page 236 was also visually
inspected using a successful PDF screenshot. The source explicitly separates
representation succinctness from supported queries/transformations and discusses
nonuniform consequences of arbitrary polynomial-size compilation. The arXiv
posting in 2011 is not the publication date.

Our full-state orbit predicate is not automatically a compilation language
with tractable clausal entailment, conditioning, model counting or forgetting.
The paper's richer requirements must not be silently credited to it. Conversely,
our source is algebraic rather than a general propositional formula. The
NP-contained-in-P/poly consequence in THEORY 9.2 is obtained using the explicit
one-source-per-n construction, not by assuming that arbitrary source-dependent
preprocessing is length-only advice.

## S4. Counting complexity

Leslie G. Valiant, *The Complexity of Enumeration and Reliability Problems*,
SIAM Journal on Computing 8(3), 410-421 (1979).
https://doi.org/10.1137/0208032

Primary publisher abstract and bibliographic record inspected. This is context
for #P and arithmetic counting reductions; its native algorithms/proofs were
not reproduced. The online posting in 2006 is not the publication date.
Our counting statement follows from the explicit parsimonious bijection from
#3SAT in THEORY 8 and the direct #P membership argument, not from an assertion
that this paper already contains the same orbit construction. It counts
states or times in one least period, never infinitely many repeated hits.

## S5. Prime sizes in the explicit source construction

J. Barkley Rosser and Lowell Schoenfeld, *Approximate formulas for some functions
of prime numbers*, Illinois Journal of Mathematics 6(1), 64-94 (1962).
https://doi.org/10.1215/ijm/1255631807

Primary publication metadata inspected. For the standard asymptotic used in
the reduction, the official NIST Digital Library of Mathematical Functions,
Section 27.12, equation 27.12.1, was inspected:
https://dlmf.nist.gov/27.12

Only p_n=O(n log(n+1)) is used. No precise finite-n numerical bound or new
number-theoretic result is claimed. Ordinary sieving of the polynomial-sized
range gives uniform construction of the first n primes. This ensures that the
all-clauses source really is polynomial-size rather than a succinctly hidden
exponential array.

## S6. Native exact-algebra comparator

SymPy number-theory documentation, inspected 27 September 2026:
https://docs.sympy.org/latest/modules/ntheory.html

Official documentation was inspected for `n_order` and `discrete_log`. The
native audit actually ran SymPy 1.14.0 on the same 42 small diagonal sources,
without supplied exponent/order/factorization hints. It returned the same
orders and source logarithms as certificate extraction. This is correctness
and baseline evidence, not a speed comparison or a native general invariant
compiler experiment. Native result bytes are in `native_results.json`.

## S7. Earlier compact-representation comparisons remain in force

The prior source dossier is `../compiled_orbits_v1/SOURCES.md`. It records
compact arithmetic circuits for torus invariants, separating monomial methods,
finite-field separating invariants, and matrix-group membership preprocessing.
Those are essential comparators. This audit does not rerun their native code or
claim to have completed a new full-paper inspection of every one of them.

The older Menezes-Wu matrix-logarithm PDF remained only partly accessible in
this pass. The attempted screenshots and direct runtime download did not close
that historical reading gap. The absence of an accessible page is not evidence
that its algorithm lacks the algebra used here. The new DDH/character comparison
already resolves a specific special-case claim without waiting for that gap.

## Claim update

| Possible paper claim | Result of this audit |
|---|---|
| Online membership avoids a fresh target logarithm | Retained as a scoped property of the checked representation |
| Source compilation is cheap because the online predicate is cheap | Rejected: current-format compilation contains a source discrete logarithm on a two-coordinate family |
| Avoiding target logarithms is itself a novel algorithmic benefit | Not established; the standard character predicate matches this family |
| Full point recognition immediately supports partial-coordinate reachability | Rejected as a general inference; the latter is NP-complete on an easy fixed-source family |
| Every partial-target negative has a polynomial-size uniformly checkable proof | Would imply NP=coNP; not a theorem supplied by our existing proof system |
| Polynomial-size unchecked source advice and efficient online queries imply P=NP | Too strong; the direct conclusion is NP contained in P/poly |
| Projection hardness is the first such result | Unsupported; S2 is direct published prior art |
| All scientific work is complete | False: the original incremental contribution and its matched general comparison remain open |

The positive result still worth auditing is a certified exact representation
for the declared full-state query class. Any proposed next extension must name
its query, witness-size and preprocessing guarantees before implementation.
No manuscript section or new broad certificate schema is warranted merely by
these boundary results.
