# Audit the preprocessing and query contract before extending it

This module checks the current exact-orbit recognizer against two precise
boundaries and a conventional compact baseline. It adds no certificate schema
or production capability. Manuscript drafting remains on hold.

**Preprocessing is not free.** For a prime-order two-coordinate diagonal source,
every accepted current-format certificate reveals a source discrete logarithm.
The underlying point-membership question expresses Diffie-Hellman consistency.
An ordinary character predicate, after the same source relation is known,
matches the compiled recognizer on every tested target.

**Ignoring coordinates is not a free query extension.** An explicit family of
Boolean coordinate permutations has a cheap full-state recognizer, while
partial-coordinate reachability is NP-complete. Each source depends only on the
number of Boolean variables, not on the formula encoded by a later projection.
The reduction preserves the exact number of solutions. Complete polynomial-size
negative certificates for every such projected query would imply NP=coNP.
These are conditional complexity boundaries, not unconditional impossibility
claims or new general reachability algorithms.

Read [THEORY.md](THEORY.md) for proofs, qualifications and the fixed-source
construction. [SOURCES.md](SOURCES.md) identifies the directly overlapping
projected-reachability literature and the unresolved priority questions. Existing
polynomial-size full-state certificates are not invalidated by a harder query.

## Reproduce

Python 3.10+ and the standard library, from a checkout or the labeled source
subset delivered with this audit:

```sh
python research/query_boundary_audit_v1/verify.py
python -O research/query_boundary_audit_v1/verify.py
```

With SymPy already installed:

```sh
python research/query_boundary_audit_v1/verify.py --sympy
```

No dependency installation or external service is performed by the verifier.
Fresh reports are generated in temporary storage and compared byte-for-byte
with `expected.json`. Optional native output is compared apart from the
reported library version. Saved evidence is never overwritten. A different
native version still requires review even if these small tests agree.

## Executed evidence

The diagonal audit uses 42 sources over primes 7, 11, 23 and 47. It compares
57,378 complete states with independently enumerated orbits and the standard
character predicate. It extracts the same logarithm from 220 reordered and
orientation-adjusted certificates. Missing mandatory alignments and false
conventional source relations fail. The optional SymPy audit solves those same
42 sources, not an unrelated benchmark.

The projected-query construction is tested on four fixed sources, with 6, 39,
394 and 2,431 Boolean coordinates. Across 1,021 formulas it checks 42,314
projection/time pairs and 7,210 Boolean assignments, including tautologies,
contradictions and empty clauses. Complete-state recognition and deliberately
changed states are independently checked. The existing generic compiler is
cross-checked on all 64 states of the six-coordinate source. Larger members
exceed its default dimension policy and are tested only with the separate,
explicit permutation recognizer; no larger generic compilation is claimed.

These are finite correctness controls for the reductions. They do not prove
an asymptotic lower bound, cryptographic hardness, novelty, or a runtime benefit.
No timing comparison, native general invariant package, analyzer frontend, or
proof-assistant verification was performed.

## Trust and integration

`boundaries.py` is audit reference code, not a hardened public verifier. The
character predicate assumes checked primes and an exact order promise, which
the audit separately validates. The fixed permutation family has explicit size
limits; they do not change the mathematical asymptotic family.

The code imports the current compiler to validate certificates before extracting
source relations. It does not modify or bypass the existing compiler checks.
No earlier result, primary schema, manifest, history file or license is edited.
The additive regression gate is `tests/test_query_boundary_research.py`.
Its publication and CI status must be read from Git or the delivery receipt,
not inferred from the existence of this source directory.
