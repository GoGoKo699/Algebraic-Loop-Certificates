"""Verify pinned audit inputs and regenerate exact evidence without overwrite."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--sympy', action='store_true', help='Run optional native source reconstruction.')
    args = parser.parse_args()
    manifest = json.loads((HERE / 'MANIFEST.json').read_text())
    for path, expected in manifest['sha256'].items():
        full = ROOT / path
        if not full.is_file() or hashlib.sha256(full.read_bytes()).hexdigest() != expected:
            raise SystemExit('Missing or changed audit dependency: ' + path)
    prefix = [sys.executable] + (['-O'] if not __debug__ else [])
    with tempfile.TemporaryDirectory(prefix='alc-query-boundary-') as td:
        fresh = Path(td) / 'results.json'
        native = Path(td) / 'native.json'
        command = prefix + [str(HERE / 'check.py'), '--output', str(fresh)]
        if args.sympy:
            command += ['--native-output', str(native)]
        subprocess.run(command, cwd=ROOT, check=True, stdout=subprocess.DEVNULL,
                       timeout=180, env={**os.environ, 'PYTHONHASHSEED': '0'})
        if fresh.read_bytes() != (HERE / 'expected.json').read_bytes():
            raise SystemExit('Exact boundary results differ; no stored evidence was overwritten.')
        if args.sympy:
            actual = json.loads(native.read_text())
            expected = json.loads((HERE / 'native_results.json').read_text())
            version = actual.pop('sympy_version')
            expected.pop('sympy_version')
            if actual != expected:
                raise SystemExit('Native source relations differ; saved report remains unchanged.')
            print('PASS: same 42 native source orders/logarithms (SymPy ' + version + ').')
    print('PASS: 57,378 diagonal comparisons and 220 reordered certificate extractions;')
    print('1,021 fixed-source projection formulas and exact assignment/count bijections.')
    print('This audits query/production boundaries, not novelty or a general performance advantage.')


if __name__ == '__main__':
    main()
