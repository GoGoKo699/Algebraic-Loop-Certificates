"""Research diagnostics of compilation and query boundaries, not a new public API.

Source order/alignment extraction and a standard cyclic-character comparator
are separate from the fixed permutation family for projected reachability.
Only finite tests enumerate states. All assertions of hardness live in THEORY.md.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import combinations, product
from math import isqrt, prod
from typing import Sequence

from alc.schema import Invalid
from research.compiled_orbits_v1.checker import compile_orbit


def diagonal_source(p: int, g: int, h: int) -> dict:
    return {'schema': 'alc.orbit-source.v1', 'field': {'kind': 'prime', 'modulus': p},
            'matrix': [[g, 0], [0, h]], 'offset': [0, 0], 'initial': [1, 1]}


def checked_log_from_alignment(source: dict, certificate: dict, q: int) -> int:
    """Extract log_g(h) from ANY accepted current-format prime-order certificate.

    Preconditions: g has the supplied prime order q and h lies in <g>. These
    are the input promise of the reduction, not claims established by this helper.
    Compilation validates the untrusted certificate before any extraction.
    Degenerate h=1,g cases are handled without an alignment witness.
    """
    compile_orbit(source, certificate)
    p = source['field']['modulus']
    g, h = source['matrix'][0][0], source['matrix'][1][1]
    if source != diagonal_source(p, g, h):
        raise Invalid('This extraction theorem is for the two-coordinate diagonal source.')
    if h == 1:
        return 0
    if h == g:
        return 1
    components = certificate['components']
    ig = next(i for i, c in enumerate(components) if c['factor'] == [(-g) % p, 1])
    ih = next(i for i, c in enumerate(components) if c['factor'] == [(-h) % p, 1])
    if components[ig]['order'] != q or components[ih]['order'] != q:
        raise Invalid('Prime-order input promise does not match the certificate.')
    e = next(e for e in certificate['comparisons'] if {e['i'], e['j']} == {ig, ih})
    # The checked relation is alpha_left = alpha_right**alignment in this case.
    s = e['alignment'] if e['i'] == ih else pow(e['alignment'], -1, q)
    if pow(g, s, p) != h:
        raise ArithmeticError('A checked relation failed its extraction theorem.')
    return s


@dataclass(frozen=True)
class CharacterPredicate:
    """Conventional prime-order diagonal comparator after checked preprocessing.

    Its construction expects the mathematical prime/order promise; use the
    existing primary prime-proof checker first when constructing from raw data.
    This is audit reference code, not an alternative trusted serialized format.
    """
    p: int
    q: int
    g: int
    h: int
    s: int

    def __post_init__(self):
        if not (0 <= self.s < self.q and 1 < self.g < self.p and
                pow(self.g, self.q, self.p) == 1 and pow(self.g, self.s, self.p) == self.h):
            raise Invalid('Invalid conventional alignment witness.')

    def query(self, state: Sequence[int]) -> bool:
        if len(state) != 2 or any(type(v) is not int or not 0 <= v < self.p for v in state):
            raise Invalid('Two canonical field elements required.')
        u, v = state
        # q prime and g!=1 prove <g> is precisely the qth roots of unity.
        return pow(u, self.q, self.p) == 1 and v == pow(u, self.s, self.p)


def first_primes(n: int) -> tuple[int, ...]:
    ps = []
    candidate = 2
    while len(ps) < n:
        if all(candidate % p for p in ps if p <= isqrt(candidate)):
            ps.append(candidate)
        candidate += 1
    return tuple(ps)


def crt_bits(bits: Sequence[int], primes: Sequence[int]) -> int:
    """Unique phase modulo product(primes), using the independent coprime CRT."""
    a, m = 0, 1
    for b, p in zip(bits, primes):
        a += m * (((b - a) * pow(m, -1, p)) % p)
        m *= p
    return a


def canonical_clause(clause: Sequence[int], variables: int) -> tuple[int, ...] | None:
    if any(type(x) is not int or x == 0 or abs(x) > variables for x in clause):
        raise ValueError('Invalid Boolean literal.')
    terms = set(clause)
    if any(-x in terms for x in terms):
        return None  # tautological, no observation needed
    if len(terms) > 3:
        raise ValueError('At most three distinct literals per clause.')
    return tuple(sorted(terms, key=abs))


def formula_value(formula: Sequence[Sequence[int]], bits: Sequence[int]) -> bool:
    return all(any((bits[abs(lit)-1] == 1) if lit > 0 else
                   (bits[abs(lit)-1] == 0) for lit in clause) for clause in formula)


@dataclass(frozen=True)
class Block:
    kind: str
    label: tuple[int, ...]
    word: tuple[int, ...]
    start: int


class FixedPermutationSource:
    """One explicit F2 permutation source per variable count, not per formula.

    Contains domain monitors and EVERY signed clause on at most three variables.
    Formula choice only selects a list of coordinates required to equal one.
    An initial unary positive-clause block anchors each prime phase; hence full
    state membership has a direct uniform polynomial-time CRT recognizer.
    """
    def __init__(self, variables: int, max_bits: int = 2_000_000):
        if type(variables) is not int or not 1 <= variables <= 32:
            raise ValueError('Implementation supports 1..32 variables, subject to byte policy.')
        self.variables = variables
        self.primes = first_primes(variables)
        specs = [('domain', (i + 1,), p) for i, p in enumerate(self.primes)]
        for arity in range(1, min(3, variables) + 1):
            for subset in combinations(range(variables), arity):
                period = prod(self.primes[i] for i in subset)
                for signs in product((-1, 1), repeat=arity):
                    specs.append(('clause', tuple(sign*(i+1) for i, sign in zip(subset, signs)), period))
        dimension = sum(v[2] for v in specs)
        if dimension > max_bits:
            raise ValueError('Explicit test-source size policy exceeded before allocation.')
        blocks, initial, permutation = [], [], []
        for kind, label, length in specs:
            start = len(initial)
            def predicate(t):
                if kind == 'domain':
                    return int(t % self.primes[label[0]-1] in (0, 1))
                return int(any(t % self.primes[abs(lit)-1] == (1 if lit > 0 else 0)
                               for lit in label))
            # Right shift gives observation at coordinate zero equal predicate(t).
            word = tuple(predicate((-j) % length) for j in range(length))
            initial.extend(word)
            permutation.extend(start + (j-1) % length for j in range(length))
            blocks.append(Block(kind, label, word, start))
        self.blocks = tuple(blocks)
        self.initial = tuple(initial)
        self.permutation = tuple(permutation)
        self.dimension = len(initial)
        self.period = prod(self.primes)
        self.by_label = {(b.kind, b.label): b for b in self.blocks}

    def step(self, state: Sequence[int]) -> tuple[int, ...]:
        return tuple(state[i] for i in self.permutation)

    def at(self, t: int) -> tuple[int, ...]:
        out = []
        for block in self.blocks:
            shift = t % len(block.word)
            out.extend(block.word[-shift:] + block.word[:-shift] if shift else block.word)
        return tuple(out)

    def projection(self, formula: Sequence[Sequence[int]]) -> tuple[int, ...]:
        coords = {b.start for b in self.blocks if b.kind == 'domain'}
        for raw in formula:
            c = canonical_clause(raw, self.variables)
            if c is None:
                continue
            if c == ():
                # The conjunction x_1 and not x_1 implements an empty clause.
                coords.update(self.by_label[('clause', c)].start for c in ((1,), (-1,)))
            else:
                coords.add(self.by_label[('clause', c)].start)
        return tuple(sorted(coords))

    def recognize(self, state: Sequence[int]) -> bool:
        if len(state) != self.dimension or any(type(v) is not int or v not in (0, 1) for v in state):
            raise ValueError('A complete canonical Boolean state is required.')
        phases = []
        for i, p in enumerate(self.primes, start=1):
            b = self.by_label[('clause', (i,))]
            word = state[b.start:b.start+p]
            if sum(word) != 1:
                return False
            phases.append((list(word).index(1) + 1) % p)
        t = crt_bits(phases, self.primes)
        return tuple(state) == self.at(t)
