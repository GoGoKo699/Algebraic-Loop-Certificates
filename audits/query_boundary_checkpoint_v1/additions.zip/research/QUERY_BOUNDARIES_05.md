# Research continuation: preprocessing is a resource, and a query is a contract

27 September 2026. Manuscript drafting remains on hold. This is an additive
scientific audit of the compiled-orbit theorem, not a new production format.

The source-only full-point recognition theorem remains intact. This pass
closes two possible overstatements of it and supplies an executed conventional
comparator. Read [the proofs](query_boundary_audit_v1/THEORY.md) and
[the primary-source assessment](query_boundary_audit_v1/SOURCES.md).

## Preprocessing obligation made exact

The orbit of (1,1) under diag(g,h), with h=g^s in a prime-order finite-field
subgroup, is the Diffie-Hellman consistency relation. In the current proof
format, complete factor coverage and compatibility force an alignment that
reveals s. The extraction works for every accepted certificate on this family,
not just for the reference producer. A polynomial-time producer for those
certificates would therefore solve the corresponding source logarithms.
This is not a lower bound for all possible orbit representations.

After s is known, the conventional predicate u^q=1 and v=u^s gives exactly the
same membership answers. Both it and our compiler agree on 57,378 full-state
cases, and native SymPy reconstructs the same 42 source relations. Compact
source preprocessing followed by cheap membership is not, by itself, a new
algorithmic contribution. No performance advantage is inferred.

## Partial-state queries are substantially stronger

A uniformly explicit family of Boolean permutation sources has cheap full-state
membership but NP-complete projected reachability. The source for n variables
contains every signed clause on up to three variables; a formula chooses only
which existing observation coordinates must equal one. Prime-phase CRT gives a
bijection from satisfying assignments to matching states in one orbit period.
The reduction is source-fixed by n and counting-preserving. Published Boolean
dynamics work already proves closely related projection hardness; priority for
our refinement is unestablished.

It follows that uniformly efficient preprocessing plus arbitrary projected
queries would imply P=NP; arbitrary polynomial-size source-only advice would
imply NP is contained in P/poly; and complete polynomial-size uniformly checked
negative projected-query certificates would imply NP=coNP. These are different
conditional conclusions. The current point certificate theorem implies none of
them. The exact range of supported queries belongs in eventual claims, not only
in a software limitation note.

## Completed in this pass

Written reductions, an explicit conventional character comparator, a fixed-source
construction with an independently proved easy full-point recognizer, exact
count-preserving tests, and updated background support for contribution and
limitation claims. The test record includes 1,021 formula/projection comparisons
on four sources and 220 current-certificate logarithm extractions under reindexing.
Native comparison is correctness-only. Old fixtures are untouched.

## Remaining scientific obligation

The overall research is not declared complete. The next decisive comparison is
whether the general source-certificate/query theorem adds a genuinely new bound
or verification capability to existing compact character and modular invariant
constructions. Neither no query-time logarithms nor a putative general safety
solver can be used as a substitute for that comparison.

A scoped positive contribution could involve a precise certificate/verification
resource guarantee or a justified restricted query extension, but such a claim
must be proved and compared before being selected as the result. Merely adding
more schemas would not resolve originality. The prior whole-paper reading gap
and lack of a native general matrix/invariant comparison remain documented.

No parent-repository edits, release, manuscript text, paid work, external contact,
or promotion of the experimental modules into the primary API is part of this
update. Operational publication is recorded separately from scientific status.
